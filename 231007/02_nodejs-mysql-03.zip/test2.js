const { odd, even } = require("./test1.js");

function test2() {
  return console.log(test1);
}
