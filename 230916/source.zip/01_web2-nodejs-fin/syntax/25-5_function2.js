function sum(first, second) {
    console.log(first + second);
}

sum(2, 4);
