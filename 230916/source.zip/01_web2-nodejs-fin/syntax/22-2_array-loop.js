var number = [1, 400, 12, 34, 5];
var i = 0;
while(i < 5) {
    console.log(number[i]);
    i = i + 1;
}
