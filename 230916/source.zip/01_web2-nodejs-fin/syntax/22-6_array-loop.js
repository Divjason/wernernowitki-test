var number = [1, 400, 12, 34];
var i = 0;
while(i < number.length) {
    console.log(number[i]);
    i = i + 1;
}
