var f = function() {
    console.log(1+1);
    console.log(1+2);
}

console.log(f);
f();
