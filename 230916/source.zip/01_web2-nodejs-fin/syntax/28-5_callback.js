function () {
    console.log('A');
}
