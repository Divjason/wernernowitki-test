var number = [1, 400, 12, 34, 5];
