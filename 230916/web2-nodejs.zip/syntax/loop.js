console.log('A');
console.log('B');
let i = 0;
while (i < 2) {
  console.log('C1');
  console.log('C2');
  i += 1;
}
console.log('D');
