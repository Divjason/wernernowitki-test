console.log(true);
console.log(false);
a = 1;
true = 1;
