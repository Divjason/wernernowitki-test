const express = require("express");
const app = express();

// 모든 경로에서 작동하게 하는 미들웨어 형태
app.use(function (req, res, next) {
  console.log("Time: ", Date.now());
  next();
});

// 특정 경로에서만 작동하게 하는 미들웨어 형태
app.use("/user/:id", function (req, res, next) {
  console.log("Request Type: ", req.method);
  next();
});

// 특정 데이터 전송방식에 따라 작동하게 하는 미들웨어 형태
app.get("/user/:id", function (req, res, next) {
  res.send("USER");
});

// 2개 이상의 복수 미들웨어를 연속으로 정의하는 형태
app.use(
  "/user/:id",
  function (req, res, next) {
    console.log("Request URL: ", req.originalUrl);
    next();
  },
  function (req, res, next) {
    console.log("Request Type: ", req.method);
    next();
  }
);
// next() 콜백함수를 사용하지 않은 경우!!!
app.get(
  "/user/:id",
  function (req, res, next) {
    console.log("ID: ", req.params.id);
    next();
  },
  function (req, res, next) {
    res.send("User Info");
  }
);

app.get("/user/:id", function (req, res, next) {
  res.end(req.params.id);
});

// 조건문을 활용해서 미들웨어 실행
app.get(
  "/user/:id",
  function (req, res, next) {
    if (req.params.id === "0") next("route");
    else next();
  },
  function (req, res, next) {
    res.send("regular");
  }
);

app.get("/user/:id", function (req, res, next) {
  res.send("special");
});
