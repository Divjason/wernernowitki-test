let testFoler = "../data";
let fs = require("fs");

fs.readdir(testFoler, function (error, filelist) {
  console.log(filelist);
});
