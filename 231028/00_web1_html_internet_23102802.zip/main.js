let http = require("http");
let fs = require("fs");
let url = require("url");

function templateHTML(title, list, body) {
  return `
    <!Doctype html>
        <html>
          <head>
              <title>WEB1 - ${title}</title>
              <meta charset="utf-8">
          </head>
          <body>
              <h1><a href="/">WEB</a></h1>
              ${list}
              <a href="/create">create</a>
              ${body}
          </body>
        </html>
    `;
}

function templateList(filelist) {
  let list = "<ul>";
  let i = 0;
  while (i < filelist.length) {
    list += `<li><a href="/?id=${filelist[i]}">${filelist[i]}</a></li>`;
    i += 1;
  }
  list += "</ul>";
  return list;
}

let app = http.createServer(function (request, response) {
  let _url = request.url;
  let queryData = url.parse(_url, true).query;
  let pathName = url.parse(_url, true).pathname;

  if (pathName === "/") {
    if (queryData.id === undefined) {
      fs.readdir("./data", function (error, filelist) {
        let title = "Welcome";
        let description = "Hello, Node.js";
        let list = templateList(filelist);
        let template = templateHTML(
          title,
          list,
          `<h2>${title}</h2><p>${description}</p>`
        );
        response.writeHead(200);
        response.end(template);
      });
    } else {
      fs.readdir("./data", function (error, filelist) {
        fs.readFile(
          `data/${queryData.id}`,
          "utf8",
          function (err, description) {
            let title = queryData.id;
            let list = templateList(filelist);
            let template = templateHTML(
              title,
              list,
              `<h2>${title}</h2><p>${description}</p>`
            );
            response.writeHead(200);
            response.end(template);
          }
        );
      });
    }
  } else if (pathName === "/create") {
    // 사용자가 글 생성 요구할 수 있는 화면 구현
  } else {
    response.writeHead(404);
    response.end("Not found");
  }
});

app.listen(3000);
