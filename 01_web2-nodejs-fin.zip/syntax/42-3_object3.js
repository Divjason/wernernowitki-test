var o = {
    v1:'v1',
    v2:'v2'
}

function f1() {
    console.log(o.v1);
}

function f2() {
    console.log(o.v2);
}

f1();
f2();
