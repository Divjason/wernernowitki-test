var a = function () {
    console.log('A');
}
a();
