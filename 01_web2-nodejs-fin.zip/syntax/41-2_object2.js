function f1() {
    console.log(1+1);
    console.log(1+2);
}
var i = if(true) {console.log(1)}
